// Tomando de la clase de funciones callbacks, armamos este esquema para obtener datos remotos
let usuariosJsonPlaceholder = null;
let usuariosDummyJSON = null;

function obtenerDatosJsonPlaceholder(callback) {
    const pedido = new XMLHttpRequest();
    pedido.open("GET", "https://jsonplaceholder.typicode.com/users");
    pedido.onload = () => {
        if (pedido.status === 200) {
            callback(null, JSON.parse(pedido.responseText));
        } else {
            callback("Error en JsonPlaceholder: " + pedido.status, null);
        }
    };
    pedido.onerror = () => callback("Error de red", null);
    pedido.send();
}

function obtenerDatosDummyJSON(callback) {
    const pedido = new XMLHttpRequest();
    pedido.open("GET", "https://dummyjson.com/users?limit=0");
    pedido.onload = () => {
        if (pedido.status === 200) {
            const respuestaObj = JSON.parse(pedido.responseText);
            callback(null, respuestaObj.users);
        } else {
            callback("Error en DummyJSON: " + pedido.status, null);
        }
    };
    pedido.onerror = () => callback("Error de red", null);
    pedido.send();
}

// Unificamos datos y preparar la agenda de contactos
function procesarAgendaCompleta() {
    // Chequeamos que las variables preparadas no estén null
    if (usuariosJsonPlaceholder !== null && usuariosDummyJSON !== null) {
        
        // Usamos el operador ...spread (punto 11)
        const usuariosUnidos = [...usuariosJsonPlaceholder, ...usuariosDummyJSON];
        //console.log("Arreglo unificado con operador ...spread:", usuariosUnidos);

        // Aprovechamos para generar con el arreglo creado la agenda de contactos
        const agenda = usuariosUnidos.map((usuario, index) => {
            let name = "";
            let lastName = "";

            // Según de qué API viene el usuario, vamos a acomodar Name y LastName (un lío)
            if (usuario.name) { 
                // JSONPlaceholder: guarda todo en 'name' 
                const partes = usuario.name.split(" ");
                name = partes[0] || "";
                lastName = partes.slice(1).join(" ") || "";
            } else { 
                // En cambio DummyJSON: tiene propiedades separadas ('firstName' y 'lastName')
                name = usuario.firstName || "";
                lastName = usuario.lastName || "";
            }

            // AComodamos las direcciones y teléfonos
            // JSONPlaceholder usa usuario.address.street y DummyJSON usa usuario.address.address
            // Así que vamos a chequear:
            let street = "Sin Datos"; 
            if (usuario.address && usuario.address.street) {
                street = usuario.address.street;
            } else if (usuario.address && usuario.address.address) {
                street = usuario.address.address;
            }
            
            //Mismo caso con city
            let city = "Sin Datos"; 
            if (usuario.address && usuario.address.city) {
                city = usuario.address.city;
            }

            const phone = usuario.phone || "Sin Datos";

            // Devolvemos el objeto con la estructura exacta que pide el PDF
            return {
                "N°": index + 1,
                "Name": name,
                "LastName": lastName,
                "Street": street,
                "City": city,
                "phone": phone
            };
        });

        // Imprimimos vía consola.log la agenda con un forEach
        console.log("Agenda de contactos:");

        agenda.forEach(contacto => {
            console.log(
                `Contacto N°${contacto["N°"]}: ${contacto.LastName}, ${contacto.Name} ` +
                `| Dirección: ${contacto.Street} (${contacto.City}) | Tel: ${contacto.phone}`
            );
        });

    }
}

// Hacemos los pedidos pasándoles sus respectivos callbacks
obtenerDatosJsonPlaceholder((error, datos) => {
    if (error) {
        console.error(error);
    } else {
        usuariosJsonPlaceholder = datos;
        procesarAgendaCompleta(); 
    }
});

obtenerDatosDummyJSON((error, datos) => {
    if (error) {
        console.error(error);
    } else {
        usuariosDummyJSON = datos;
        procesarAgendaCompleta(); 
    }
});
