// Estudiantes ejemplo según consigna
const alumnos = ["Juan Perez", "Leo Messi", "Mirtha Legrand"];

// Vector q tiene las cuatro materias del segundo cuatrimestre
const materias = ["Matemática", "Informática", "Inglés", "Bases de datos"];

// Cada fila corresponde a un estudiante y cada columna a una materia, odenado todo
const notas = [[8,6,7,9], [8,6,7,9], [8,6,7,9]];

console.log("Vector estudiantes: ", alumnos);
console.log("Vector materias: ", materias);
console.log("Vector notas: ", notas);