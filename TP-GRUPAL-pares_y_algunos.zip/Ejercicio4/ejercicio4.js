// Resuelto luego de consulta en foro: notar la modificación de address.city === 'Phoenix'
fetch('https://dummyjson.com/users?limit=0')
.then(response => response.json())
.then(data => {
const usuariosDePhoenix = data.users.filter(user => user.address.city === 'Phoenix'); //filtramos
const total = usuariosDePhoenix.length; //contamos la cantidad de elementos del nuevo arreglo

console.log(`Total de usuarios de la ciudad de Phoenix: ${total}`);

})
.catch(error => {
console.error('Error al consultar la API. Tipo de error: ', error);
});