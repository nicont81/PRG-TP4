// Traemos desde el APIendpoint los datos
fetch('https://dummyjson.com/users?limit=0')
.then(respuesta => respuesta.json())
.then(datos => {
   
    const usuarios = datos.users; //Traemos datos de usuarios
    
    const edadesUsuarios = datos.users.reduce((sumador,usuario) => sumador + usuario.age, 0); //Sumatoria de edades

    const promEdad = edadesUsuarios / usuarios.length;
    
    console.log(`La edad promedio es: ${promEdad.toFixed(1)} años.`); //toFixed(1) nos permite poner un decimal
})
.catch(error => {
console.error('Error al consultar la API. Tipo de error: ', error);
});