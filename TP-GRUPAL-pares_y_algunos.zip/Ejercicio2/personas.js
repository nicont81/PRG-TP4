export const personas = [
  {
    nombre: "Romina",
    apellido: "Nuñez",
    edad: 25,
  },
  {
    nombre: "Luis",
    apellido: "Leiva",
    edad: 35,
  },
];