import { personas } from "./personas.js"

console.log("Usamos push() para añadir ítem");
//Método mutable push para añadir un ítem al arreglo
//Como salida, mostrará la loncantidad nueva de elementos del arreglo.
console.log(personas.push({
   nombre: "Nico",
   apellido: "Ticac",
   edad: 45,
  }));

console.log("Listamos el arreglo \"personas\"");

//Listar las personas del arreglo
personas.forEach(function(listar) {
    console.log(listar); });

console.log("Usamos map() para generar un nuevo arreglo sin tocar el orginal:");
const nombres = personas.map((persona) => {
   return {
    nombrecompleto: persona.nombre + " " + persona.apellido,
    edad: persona.edad,
   };
});
//console.log(nombres);

console.log("Listar el nuevo arreglo \"nombres\"");

//Listar las personas del arreglo
nombres.forEach(function(listar) {
    console.log(listar); });