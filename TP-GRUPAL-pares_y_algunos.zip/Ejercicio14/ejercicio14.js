fetch('https://dummyjson.com/carts?limit=0')
  .then(resul => resul.json())
  .then(datos => {
    const nuevoArreglo = datos.carts.map(carrito => {
      if (carrito.products.length >= 4) {
        const productosModificados = carrito.products.map((prod, primerprod) => {
          if (primerprod === 0) {
            return {
              ...prod,
              desc: prod.price * 50 / 100
            };
          }
          return prod;
        });

        return {
          ...carrito,
          products: productosModificados
        };
      }
      return carrito;
    });

    console.log(nuevoArreglo);
  });

  