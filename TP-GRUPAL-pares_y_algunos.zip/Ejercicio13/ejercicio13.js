// COmenzamos con el primer punto del 13

fetch('https://jsonplaceholder.typicode.com/users')
  .then(resul => resul.json())
  .then(datos => {
    const arregloResultante = datos.map(usuario => ({
      ...usuario,
      domicilio: `${usuario.address.street}, ${usuario.address.city}`
    }));
    //console.log("Arreglo con domicilio:");
    //console.log(arregloResultante);
  });

// punto 13.2
  fetch('https://jsonplaceholder.typicode.com/users')
  .then(resul => resul.json())
  .then(datos => {
    const arregloIPAP = datos.map(usuario => ({
      ...usuario,
      company: {
        ...usuario.company,
        name: 'IPAP'
      }
    }));
    //console.log("Arreglo con IPAP:");
    //console.log(arregloIPAP);
  });

  // punto 13.3
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(resul => resul.json())
    .then(datos => {
    const anidados = datos.map(usuario => ({ ...usuario, domicilio: `${usuario.address.street}, ${usuario.address.city}`, company: { ...usuario.company, name: 'IPAP' } }));
    console.log("Resultado del arreglo anidado:");
    console.log(anidados);
    
  });
