// Estudiantes ejemplo según consigna
const alumnos = ["Juan Perez", "Leo Messi", "Mirtha Legrand"];

// Vector q tiene las cuatro materias del segundo cuatrimestre
const materias = ["Matemática", "Informática", "Inglés", "Bases de datos"];

// Cada fila corresponde a un estudiante y cada columna a una materia, odenado todo
const notas = [[8,6,7,9], [8,6,7,9], [8,6,7,9]];

/* console.log("Vector estudiantes: ", alumnos);
   console.log("Vector materias: ", materias);
   console.log("Vector notas: ", notas); */



console.log(".::Todas las notas con nombre de estudiante y materia::.");

// Recorremos cada alumno (filas de la matriz) según documento 4.Arreglos_multidimensionales.pdf
for (let i = 0; i < alumnos.length; i++) {
  console.log(`Notas de ${alumnos[i]}:`);
  
  // Recorremos cada materia para el estudiante actual (x columnas)
  for (let j = 0; j < materias.length; j++) {
    console.log(`* ${materias[j]}: ${notas[i][j]}`);
  }
}

console.log(".::Promedio de cada estudiante::.");

// Recorremos nuevamente los alumnos para calcular sus promedios
for (let i = 0; i < alumnos.length; i++) {
  let sumaNotas = 0;

  // Sumamos todas las notas del alumno actual
  for (let j = 0; j < notas[i].length; j++) {
    sumaNotas += notas[i][j];
  }

  // Calculamos el promedio dividiendo la suma por la cantidad de materias
  let promedio = sumaNotas / notas[i].length;

  // Mostramos el resultado (usando .toFixed(1) para mostrar solo 1 decimal)
  console.log(`El promedio de ${alumnos[i]} es: ${promedio.toFixed(1)}`);
}