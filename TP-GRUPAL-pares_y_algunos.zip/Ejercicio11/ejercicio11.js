//Tomando de la clase de funciones callbacks, armamos este esquema
//para obtener datos remotos

// definimos un par de variables que servirán para saber si está vacío o si ya cargó la info remota
let usuariosJsonPlaceholder = null;
let usuariosDummyJSON = null;

function obtenerDatosJsonPlaceholder(callback) {
    const pedido = new XMLHttpRequest();
    pedido.open("GET", "https://jsonplaceholder.typicode.com/users");
    pedido.onload = () => {
        if (pedido.status === 200) {
            // Pasamos el texto JSON a un arreglo de JavaScript
            callback(null, JSON.parse(pedido.responseText));
        } else {
            callback("Error en JsonPlaceholder: " + pedido.status, null);
        }
    };
    pedido.onerror = () => callback("Error de red", null);
    pedido.send();
}

function obtenerDatosDummyJSON(callback) {
    const pedido = new XMLHttpRequest();
    pedido.open("GET", "https://dummyjson.com/users?limit=0");
    pedido.onload = () => {
        if (pedido.status === 200) {
            // DummyJSON devuelve un objeto. Extraemos el arreglo de la propiedad '.users'
            const respuestaObj = JSON.parse(pedido.responseText);
            callback(null, respuestaObj.users);
        } else {
            callback("Error en DummyJSON: " + pedido.status, null);
        }
    };
    pedido.onerror = () => callback("Error de red", null);
    pedido.send();
}

// Primero vamos a verificar la sincro y unir los datos con spread (...)
function unirUsuariosConSpread() {
    // Chequeamos que nuestras variables no estén null
    if (usuariosJsonPlaceholder !== null && usuariosDummyJSON !== null) {
        
        // Unimos con el operador ...spread
        const usuariosUnidos = [...usuariosJsonPlaceholder, ...usuariosDummyJSON];
        
        // Imprimimos el resultado final 
        console.log("Usuarios unidos en un único arreglo:");
        console.log(usuariosUnidos);
    }
}

// Hacemos los pedidos pasándoles sus respectivos callbacks
obtenerDatosJsonPlaceholder((error, datos) => {
    if (error) {
        console.error(error);
    } else {
        usuariosJsonPlaceholder = datos;
        unirUsuariosConSpread(); // Intentamos realizar la unión
    }
});

obtenerDatosDummyJSON((error, datos) => {
    if (error) {
        console.error(error);
    } else {
        usuariosDummyJSON = datos;
        unirUsuariosConSpread(); // Intentamos realizar la unión
    }
});
