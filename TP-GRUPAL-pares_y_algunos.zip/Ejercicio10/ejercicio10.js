// Traemos desde el APIendpoint los datos
fetch('https://dummyjson.com/users?limit=0')
.then(respuesta => respuesta.json())
.then(datos => {
      const datosUsuarios = datos.users; //arreglo orig. con los datos obtenidos

      const usuariosActualizados = datosUsuarios.map(usuario => {
      // Se crea copia para hacer las modificaciones...
      const usuarioEditado = { ...usuario, bank: { ...usuario.bank } };
        if (usuarioEditado.bank.cardType === "Discover") {
          usuarioEditado.bank.cardType = "Visa Argentina";
        } else if (usuarioEditado.bank.cardType === "Diners Club International") {
          usuarioEditado.bank.cardType = "Diners Argentina";
        }
      return usuarioEditado;
    });

    //Muestra el resultado en la consola
    console.log("Usuarios actualizados:", usuariosActualizados);
  })
  
.catch(error => {
console.error('Error al consultar la API. Tipo de error: ', error);
});