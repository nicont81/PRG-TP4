//Declaramos variables que usaremos y las inicializamos
let revisados = 0, eliminados = 0;
// Traemos desde el APIendpoint los datos
fetch('https://jsonplaceholder.typicode.com/comments')
.then(respuesta => respuesta.json())
.then(datos => {
   
    const comentarios = datos; //Traemos datos de comments

    for (let i = comentarios.length - 1; i >= 0; i--) {
      revisados++; // Contamos cada comentario revisado

      if (comentarios[i].postId === 5) {
        comentarios.splice(i, 1); // Eliminamos el elemento actual
        eliminados++; // Contamos el comentario eliminado
      }
    }

    console.log(`La cantidad de comentarios que se revisaron: ${revisados}`);
    console.log(`La cantidad de comentarios que se eliminaron: ${eliminados}`);
    console.log(`Total de registros que quedaron: ${comentarios.length}`);

})
.catch(error => {
console.error('Error al consultar la API. Tipo de error: ', error);
});

